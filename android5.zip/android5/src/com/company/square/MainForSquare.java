package com.company.square;

public class MainForSquare {
    public static void main(String[] args) {

    }
}
