package com.company.hoodies;

public class Hoodies {
    String material;
    String size;
    String color;
    String creator;
}
