package com.company.rectangle;

public class MainForRectangle {

    public static void main(String[] args) {
    }
}
