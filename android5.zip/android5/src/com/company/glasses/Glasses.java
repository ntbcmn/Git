package com.company.glasses;

public class Glasses {
    String frameColor;
    double leftLens;
    double rightLens;
    String lensesColor;
}
