package com.company.person;

public class MainForPerson {
    public static void main(String[] args) {

    }
}
